#!/bin/bash

# CLIC 2021
python eval_PICS.py --data_root "/home/eric/data" --lam_sketch 0.5 --dataset "CLIC2021"